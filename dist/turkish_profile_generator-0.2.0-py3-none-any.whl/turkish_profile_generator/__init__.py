__version__ = "0.2.0"

from .UserProfileGenerator import *

def __init__(self, min_age, max_age, gender=None):
    self.min_age = min_age
    self.max_age = max_age